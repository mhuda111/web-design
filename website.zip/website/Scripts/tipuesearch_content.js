
var tipuesearch = {"pages": [
     
     {"title": "Asia", "text": "A collection of ancient sites throughout Asia.", "tags": "Asia", "url": "asia.html"},
     {"title": "South America", "text": "An occasional blog covering CSS, web development, etc.", "tags": "South America", "url": "southamerica.html"},
     {"title": "North America", "text": "An occasional blog covering CSS, web development, etc.", "tags": "North America", "url": "northamerica.html"},
     {"title": "Central America", "text": "An occasional blog covering CSS, web development, etc.", "tags": "Central America", "url": "centralamerica.html"},
     {"title": "Europe", "text": "An occasional blog covering CSS, web development, etc.", "tags": "Europe Colosseum Acropolis Of Athens Leaning Tower of Pisa Ephesus Stonehenge Nemrut", "url": "europe.html"},
     {"title": "Africa", "text": "An occasional blog covering CSS, web development, etc.", "tags": "Africa", "url": "africa.html"},
     {"title": "Home", "text": "An occasional blog covering CSS, web development, etc.", "tags": "Home", "url": "index.html"},
     {"title": "Contact Us", "text": "This page provides our contact information.", "tags": "contact", "url": "contact.html"},
     {"title": "Traveler's Blog", "text": "This page shares our sites stories.", "tags": "blog", "url": "blog.html"},
     {"title": "About Us", "text": "This page provides information about our team.", "tags": "about us team", "url": "about.html"},
     {"title": "Google", "text": "Search Engine", "tags": "Google search", "url": "www.google.com"},
     {"title": "Yahoo", "text": "Search Engine", "tags": "Yahoo search", "url": "www.yahoo.com"},
     {"title": "Bing", "text": "Search Engine", "tags": "Bing search", "url": "www.bing.com"}
]};



